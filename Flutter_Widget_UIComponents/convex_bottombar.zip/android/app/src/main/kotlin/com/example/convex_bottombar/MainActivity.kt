package com.example.convex_bottombar

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
