import 'package:convex_bottom_bar/convex_bottom_bar.dart';
import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatefulWidget {
  @override
  State createState() => _State();
}

class _State extends State<MyApp> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      initialRoute: "/",
      routes: {
        "/": (BuildContext context) => HelloConvexAppBar(),
      },
    );
  }
}

class HelloConvexAppBar extends StatefulWidget {
  @override
  _HelloConvexAppBarState createState() => _HelloConvexAppBarState();
}

class _HelloConvexAppBarState extends State<HelloConvexAppBar> {
  int _currentIndex = 1; // Default index

  // Lista sa mga background color kada tab
  final List<Color> _backgroundColors = [
    Colors.blue.withOpacity(0.3),
    Colors.red.withOpacity(0.3),
    Colors.yellow.withOpacity(0.3),
  ];

  @override
  Widget build(BuildContext context) {
    // Lista sa mga content nga ipakita kada tab (ibalhin dinhi sulod sa build method)
    final List<Widget> _pages = [
      // PLAY CONTENT
      SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(20),
          child: Column(
            children: [
              Icon(Icons.play_arrow, size: 80, color: Colors.blue),
              SizedBox(height: 20),
              Text('Video Player',
                  style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
              SizedBox(height: 15),
              Container(
                width: 200,
                height: 120,
                decoration: BoxDecoration(
                  color: Colors.blue.shade200,
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Icon(Icons.play_circle_filled,
                    size: 50, color: Colors.white),
              ),
              SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ElevatedButton.icon(
                    onPressed: () {},
                    icon: Icon(Icons.skip_previous),
                    label: Text('Previous'),
                  ),
                  ElevatedButton.icon(
                    onPressed: () {},
                    icon: Icon(Icons.pause),
                    label: Text('Pause'),
                  ),
                  ElevatedButton.icon(
                    onPressed: () {},
                    icon: Icon(Icons.skip_next),
                    label: Text('Next'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),

      // MUSEUM CONTENT
      SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(20),
          child: Column(
            children: [
              Icon(Icons.museum, size: 80, color: Colors.red),
              SizedBox(height: 20),
              Text('Art Gallery',
                  style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
              SizedBox(height: 15),
              Wrap(
                spacing: 15,
                runSpacing: 15,
                children: [
                  _buildArtItem('Painting', Icons.palette, Colors.orange),
                  _buildArtItem('Sculpture', Icons.architecture, Colors.green),
                  _buildArtItem('History', Icons.history, Colors.purple),
                  _buildArtItem('Ancient', Icons.auto_awesome, Colors.brown),
                ],
              ),
              SizedBox(height: 20),
              Card(
                color: Colors.white.withOpacity(0.8),
                child: Padding(
                  padding: EdgeInsets.all(15),
                  child: Column(
                    children: [
                      Text('Featured Exhibit',
                          style: TextStyle(
                              fontSize: 20, fontWeight: FontWeight.bold)),
                      SizedBox(height: 10),
                      Text('Ancient Artifacts Collection',
                          style: TextStyle(fontSize: 16)),
                      SizedBox(height: 10),
                      LinearProgressIndicator(value: 0.7),
                      SizedBox(height: 5),
                      Text('70% visited', style: TextStyle(fontSize: 12)),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),

      // BOOK CONTENT
      SingleChildScrollView(
          child: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          children: [
            Icon(Icons.book, size: 80, color: Colors.orange),
            SizedBox(height: 20),
            Text('Library',
                style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
            SizedBox(height: 15),
            _buildBookCard('Flutter Guide', 'Dart Programming', Icons.code),
            _buildBookCard(
                'Design Patterns', 'Software Engineering', Icons.computer),
            _buildBookCard('History Book', 'World History', Icons.public),
            _buildBookCard(
                'Science Book', 'Physics & Chemistry', Icons.science),
          ],
        ),
      ))
    ];

    return Scaffold(
      backgroundColor: _backgroundColors[_currentIndex],
      appBar: AppBar(
        title: Text('GeeksForGeeks'),
        backgroundColor: Colors.green,
        foregroundColor: Colors.white,
      ),
      body: _pages[_currentIndex],
      bottomNavigationBar: ConvexAppBar(
        style: TabStyle.react,
        backgroundColor: Colors.green,
        activeColor: Colors.blue,
        color: Colors.white,
        items: [
          TabItem(icon: Icons.play_arrow, title: 'Play'),
          TabItem(icon: Icons.museum, title: 'Museum'),
          TabItem(icon: Icons.book, title: 'Book'),
        ],
        initialActiveIndex: _currentIndex,
        onTap: (int index) {
          setState(() {
            _currentIndex = index;
          });
          print('click index=$index');
        },
      ),
    );
  }

  // Helper method para sa museum items
  Widget _buildArtItem(String title, IconData icon, Color color) {
    return Container(
      width: 100,
      height: 100,
      decoration: BoxDecoration(
        color: color.withOpacity(0.2),
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: color, width: 2),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, size: 30, color: color),
          SizedBox(height: 5),
          Text(title,
              style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  // Helper method para sa book cards
  Widget _buildBookCard(String title, String subtitle, IconData icon) {
    return Card(
      margin: EdgeInsets.symmetric(vertical: 8),
      color: Colors.white.withOpacity(0.9),
      child: ListTile(
        leading: Icon(icon, size: 40, color: Colors.orange),
        title: Text(title, style: TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(subtitle),
        trailing: Icon(Icons.arrow_forward_ios, color: Colors.grey),
        onTap: () {},
      ),
    );
  }
}
